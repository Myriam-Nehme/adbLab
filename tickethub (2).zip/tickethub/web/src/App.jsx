import { useEffect, useState } from 'react';
import { api } from './api.js';
import EventsPage from './pages/EventsPage.jsx';
import EventPage from './pages/EventPage.jsx';
import LoginPage from './pages/LoginPage.jsx';
import MyBookingsPage from './pages/MyBookingsPage.jsx';
import StaffPage from './pages/StaffPage.jsx';
import { go } from './router.js';

function useHashRoute() {
  const [hash, setHash] = useState(window.location.hash || '#/events');
  useEffect(() => {
    const onChange = () => setHash(window.location.hash || '#/events');
    window.addEventListener('hashchange', onChange);
    return () => window.removeEventListener('hashchange', onChange);
  }, []);
  return hash.replace(/^#/, '').split('/').filter(Boolean);   // "#/events/12" -> ["events", "12"]
}

export default function App() {
  const route = useHashRoute();
  const [user, setUser] = useState(null);
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    api.me().then(setUser).catch(() => setUser(null)).finally(() => setChecked(true));
  }, []);

  async function logout() {
    await api.logout();
    setUser(null);
    go('/events');
  }

  let page;
  const [section, id] = route;
  if (section === 'events' && id) page = <EventPage eventId={Number(id)} user={user} />;
  else if (section === 'login') page = <LoginPage onLogin={setUser} />;
  else if (section === 'bookings') page = <MyBookingsPage user={user} />;
  else if (section === 'staff') page = <StaffPage user={user} />;
  else page = <EventsPage />;

  return (
    <>
      <header className="topbar">
        <a className="brand" href="#/events">TicketHub</a>
        <nav>
          <a href="#/events" className={section === 'events' || !section ? 'active' : ''}>Events</a>
          {user && <a href="#/bookings" className={section === 'bookings' ? 'active' : ''}>My bookings</a>}
          {user?.role === 'Staff' && <a href="#/staff" className={section === 'staff' ? 'active' : ''}>Staff</a>}
        </nav>
        <div className="who">
          {user ? (
            <>
              <span>{user.fullName}{user.role === 'Staff' ? ' (staff)' : ''}</span>
              <button className="link" onClick={logout}>Log out</button>
            </>
          ) : (
            <a href="#/login">Log in</a>
          )}
        </div>
      </header>
      <main className="container">{checked ? page : <p className="muted">Loading…</p>}</main>
    </>
  );
}
