async function request(path, options = {}) {
  const response = await fetch(path, {
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json' },
    ...options
  });

  if (response.status === 204) return null;

  const data = await response.json().catch(() => null);

  if (!response.ok) {
    const error = new Error(errorMessage(data, response.status));
    error.status = response.status;
    throw error;
  }
  return data;
}

function errorMessage(data, status) {
  if (data?.error) return data.error;
  if (data?.errors) {
    const first = Object.values(data.errors)[0];
    if (first?.length) return first[0];
  }
  if (status === 401) return 'Please log in first.';
  if (status === 403) return 'This page is for staff only.';
  return `Something went wrong (HTTP ${status}).`;
}

const post = (path, body) => request(path, { method: 'POST', body: JSON.stringify(body ?? {}) });

export const api = {

  me: () => request('/api/auth/me'),
  login: (email, password) => post('/api/auth/login', { email, password }),
  register: (fullName, email, password) => post('/api/auth/register', { fullName, email, password }),
  logout: () => post('/api/auth/logout'),

  upcomingEvents: () => request('/api/events'),
  event: (id) => request(`/api/events/${id}`),
  seats: (id) => request(`/api/events/${id}/seats`),

  book: (eventId, seatIds) => post('/api/bookings', { eventId, seatIds }),
  myBookings: () => request('/api/bookings/mine'),
  cancel: (bookingId) => post(`/api/bookings/${bookingId}/cancel`),

  venues: () => request('/api/venues'),
  createEvent: (event) => post('/api/events', event),
  salesReport: (from, to) => request(`/api/reports/sales?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}`),
  monthlySales: (year) => request(`/api/reports/monthly?year=${encodeURIComponent(year)}`),
  eventSales: (id) => request(`/api/events/${id}/sales`)
};

export const money = (value) =>
  new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);

export const dateTime = (value) =>
  new Date(value).toLocaleString('en-GB', {
    weekday: 'short', day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'
  });
