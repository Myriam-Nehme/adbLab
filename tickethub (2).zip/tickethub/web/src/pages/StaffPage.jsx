import { useEffect, useState } from 'react';
import { api, dateTime, money } from '../api.js';

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const isoDate = (d) => d.toISOString().slice(0, 10);
const addDays = (days) => { const d = new Date(); d.setDate(d.getDate() + days); return d; };

export default function StaffPage({ user }) {
  if (!user) return <p>Please <a href="#/login">log in</a> with a staff account.</p>;
  if (user.role !== 'Staff') return <p className="error">This page is for staff only.</p>;

  return (
    <>
      <h1>Staff</h1>
      <SalesReport />
      <MonthlyReport />
      <CreateEvent />
    </>
  );
}

function SalesReport() {
  const [from, setFrom] = useState(isoDate(addDays(-90)));
  const [to, setTo] = useState(isoDate(addDays(90)));
  const [rows, setRows] = useState(null);
  const [details, setDetails] = useState({});        // eventId -> category rows
  const [error, setError] = useState('');

  async function run(e) {
    e?.preventDefault();
    setError('');
    try {
      setRows(await api.salesReport(from, to));
      setDetails({});
    } catch (err) {
      setError(err.message);
    }
  }

  useEffect(() => { run(); }, []);

  async function toggleDetails(eventId) {
    if (details[eventId]) {
      const copy = { ...details };
      delete copy[eventId];
      setDetails(copy);
      return;
    }
    try {
      const sales = await api.eventSales(eventId);
      setDetails({ ...details, [eventId]: sales });
    } catch (err) {
      setError(err.message);
    }
  }

  const totalTickets = rows?.reduce((s, r) => s + r.ticketsSold, 0) ?? 0;
  const totalRevenue = rows?.reduce((s, r) => s + r.revenue, 0) ?? 0;

  return (
    <section className="panel">
      <h2>Sales per event</h2>
      <form className="inline-form" onSubmit={run}>
        <label>From <input id="salesFrom" type="date" value={from} onChange={(e) => setFrom(e.target.value)} required /></label>
        <label>To <input id="salesTo" type="date" value={to} onChange={(e) => setTo(e.target.value)} required /></label>
        <button>Show</button>
      </form>
      {error && <p className="error">{error}</p>}
      {rows && (
        <div className="table-wrap">
          <table>
            <thead>
              <tr><th>Event</th><th>Date</th><th>Venue</th><th>Tickets</th><th>Fill</th><th>Revenue</th><th></th></tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <FragmentRow key={r.eventId} row={r} details={details[r.eventId]} onToggle={() => toggleDetails(r.eventId)} />
              ))}
            </tbody>
            <tfoot>
              <tr><td colSpan={3}>{rows.length} events</td><td className="num">{totalTickets}</td><td></td><td className="num">{money(totalRevenue)}</td><td></td></tr>
            </tfoot>
          </table>
        </div>
      )}
    </section>
  );
}

function FragmentRow({ row, details, onToggle }) {
  return (
    <>
      <tr className={row.status === 'Cancelled' ? 'dim' : ''}>
        <td>{row.title}{row.status === 'Cancelled' ? ' (cancelled)' : ''}</td>
        <td>{dateTime(row.eventDate)}</td>
        <td>{row.venueName}</td>
        <td className="num">{row.ticketsSold} / {row.capacity}</td>
        <td className="num">{row.fillRatePct}%</td>
        <td className="num">{money(row.revenue)}</td>
        <td><button className="secondary small" onClick={onToggle}>{details ? 'Hide' : 'Details'}</button></td>
      </tr>
      {details && (
        <tr className="details">
          <td colSpan={7}>
            {details.length === 0 ? 'No tickets sold.' :
              details.map((d) => `${d.category}: ${d.ticketsSold} tickets, ${money(d.revenue)}`).join(' · ')}
          </td>
        </tr>
      )}
    </>
  );
}

function MonthlyReport() {
  const thisYear = new Date().getFullYear();
  const [year, setYear] = useState(thisYear);
  const [rows, setRows] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    setError('');
    api.monthlySales(year).then(setRows).catch((e) => setError(e.message));
  }, [year]);

  return (
    <section className="panel">
      <h2>Monthly revenue</h2>
      <label>Year{' '}
        <select id="year" value={year} onChange={(e) => setYear(Number(e.target.value))}>
          {[thisYear - 2, thisYear - 1, thisYear, thisYear + 1].map((y) => <option key={y} value={y}>{y}</option>)}
        </select>
      </label>
      {error && <p className="error">{error}</p>}
      {rows && rows.length === 0 && <p className="muted">No sales in {year}.</p>}
      {rows && rows.length > 0 && (
        <div className="table-wrap">
          <table>
            <thead><tr><th>Month</th><th>Tickets</th><th>Revenue</th><th>Running total</th></tr></thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.month}>
                  <td>{MONTHS[r.month - 1]}</td>
                  <td className="num">{r.ticketsSold}</td>
                  <td className="num">{money(r.revenue)}</td>
                  <td className="num">{money(r.runningRevenue)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}

function CreateEvent() {
  const [venues, setVenues] = useState([]);
  const [form, setForm] = useState({ venueId: '', title: '', eventDate: '', standardPrice: '', vipPrice: '' });
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  useEffect(() => {
    api.venues().then(setVenues).catch((e) => setError(e.message));
  }, []);

  const set = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  async function submit(e) {
    e.preventDefault();
    setError('');
    setNotice('');
    try {
      const result = await api.createEvent({
        venueId: Number(form.venueId),
        title: form.title,
        eventDate: `${form.eventDate}:00`,          // "2026-12-01T20:00" -> add seconds
        standardPrice: Number(form.standardPrice),
        vipPrice: Number(form.vipPrice)
      });
      setNotice(`Event #${result.eventId} created. It now appears on the Events page.`);
      setForm({ venueId: '', title: '', eventDate: '', standardPrice: '', vipPrice: '' });
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <section className="panel">
      <h2>Create an event</h2>
      <form className="form grid2" onSubmit={submit}>
        <label>Venue
          <select id="venueId" value={form.venueId} onChange={set('venueId')} required>
            <option value="">Choose…</option>
            {venues.map((v) => <option key={v.venueId} value={v.venueId}>{v.name} ({v.city})</option>)}
          </select>
        </label>
        <label>Title
          <input id="title" value={form.title} onChange={set('title')} required maxLength={150} />
        </label>
        <label>Date and time
          <input id="eventDate" type="datetime-local" value={form.eventDate} onChange={set('eventDate')} required />
        </label>
        <label>Standard price ($)
          <input id="standardPrice" type="number" min="0.01" step="0.01" value={form.standardPrice} onChange={set('standardPrice')} required />
        </label>
        <label>VIP price ($)
          <input id="vipPrice" type="number" min="0.01" step="0.01" value={form.vipPrice} onChange={set('vipPrice')} required />
        </label>
        <div className="form-actions"><button>Create event</button></div>
      </form>
      {notice && <p className="success">{notice}</p>}
      {error && <p className="error">{error}</p>}
    </section>
  );
}
