import { useEffect, useState } from 'react';
import { api, dateTime, money } from '../api.js';

export default function EventsPage() {
  const [events, setEvents] = useState(null);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');

  useEffect(() => {
    api.upcomingEvents().then(setEvents).catch((e) => setError(e.message));
  }, []);

  if (error) return <p className="error">{error}</p>;
  if (!events) return <p className="muted">Loading events…</p>;

  const term = search.trim().toLowerCase();
  const shown = events.filter(
    (e) => !term || e.title.toLowerCase().includes(term) || e.city.toLowerCase().includes(term)
  );

  return (
    <>
      <div className="page-head">
        <h1>Upcoming events</h1>
        <input
          className="search"
          placeholder="Search by title or city"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {shown.length === 0 && <p className="muted">No events found.</p>}

      <div className="cards">
        {shown.map((e) => {
          const soldOut = e.seatsLeft === 0;
          return (
            <a key={e.eventId} className="card" href={`#/events/${e.eventId}`}>
              <h3>{e.title}</h3>
              <p className="muted">{dateTime(e.eventDate)}</p>
              <p>{e.venueName}, {e.city}</p>
              <p>From {money(e.standardPrice)} · VIP {money(e.vipPrice)}</p>
              <p className={soldOut ? 'badge soldout' : 'badge'}>
                {soldOut ? 'Sold out' : `${e.seatsLeft} of ${e.capacity} seats left`}
              </p>
            </a>
          );
        })}
      </div>
    </>
  );
}
