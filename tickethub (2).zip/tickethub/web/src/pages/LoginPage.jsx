import { useState } from 'react';
import { api } from '../api.js';
import { go } from '../router.js';

export default function LoginPage({ onLogin }) {
  const [mode, setMode] = useState('login');           // 'login' or 'register'
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      const user = mode === 'login'
        ? await api.login(email, password)
        : await api.register(fullName, email, password);
      onLogin(user);
      const next = sessionStorage.getItem('afterLogin') || (user.role === 'Staff' ? '/staff' : '/events');
      sessionStorage.removeItem('afterLogin');
      go(next);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="narrow">
      <h1>{mode === 'login' ? 'Log in' : 'Create an account'}</h1>

      <form onSubmit={submit} className="form">
        {mode === 'register' && (
          <label>Full name
            <input id="fullName" value={fullName} onChange={(e) => setFullName(e.target.value)} required maxLength={100} />
          </label>
        )}
        <label>Email
          <input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required maxLength={255} />
        </label>
        <label>Password
          <input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)}
                 required minLength={mode === 'register' ? 8 : 1} maxLength={100} />
        </label>
        {error && <p className="error">{error}</p>}
        <button disabled={busy}>{busy ? 'Please wait…' : mode === 'login' ? 'Log in' : 'Create account'}</button>
      </form>

      <p>
        {mode === 'login' ? 'No account yet? ' : 'Already have an account? '}
        <button className="link" onClick={() => { setMode(mode === 'login' ? 'register' : 'login'); setError(''); }}>
          {mode === 'login' ? 'Create one' : 'Log in'}
        </button>
      </p>

      <div className="hint">
        <strong>Demo accounts</strong><br />
        Customer: demo@tickethub.com / Demo123!<br />
        Second customer: demo2@tickethub.com / Demo123!<br />
        Staff: staff@tickethub.com / Staff123!
      </div>
    </div>
  );
}
