import { useCallback, useEffect, useState } from 'react';
import { api, dateTime, money } from '../api.js';

export default function MyBookingsPage({ user }) {
  const [bookings, setBookings] = useState(null);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  const load = useCallback(() => {
    api.myBookings().then(setBookings).catch((e) => setError(e.message));
  }, []);

  useEffect(() => {
    if (user) load();
  }, [user, load]);

  async function cancel(booking) {
    if (!window.confirm(`Cancel booking #${booking.bookingId} for ${booking.title}?`)) return;
    setError('');
    setNotice('');
    try {
      await api.cancel(booking.bookingId);
      setNotice(`Booking #${booking.bookingId} cancelled. The seats are free again.`);
      load();
    } catch (e) {
      setError(e.message);
    }
  }

  if (!user) return <p>Please <a href="#/login">log in</a> to see your bookings.</p>;
  if (error && !bookings) return <p className="error">{error}</p>;
  if (!bookings) return <p className="muted">Loading…</p>;

  return (
    <>
      <h1>My bookings</h1>
      {notice && <p className="success">{notice}</p>}
      {error && <p className="error">{error}</p>}
      {bookings.length === 0 && <p className="muted">You have no bookings yet. <a href="#/events">Find an event</a>.</p>}

      {bookings.length > 0 && (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>#</th><th>Event</th><th>Date</th><th>Seats</th><th>Total</th><th>Status</th><th></th>
              </tr>
            </thead>
            <tbody>
              {bookings.map((b) => (
                <tr key={b.bookingId} className={b.status === 'Cancelled' ? 'dim' : ''}>
                  <td>{b.bookingId}</td>
                  <td>{b.title}<br /><span className="muted">{b.venueName}</span></td>
                  <td>{dateTime(b.eventDate)}</td>
                  <td>{b.seats}</td>
                  <td className="num">{money(b.totalAmount)}</td>
                  <td>{b.status}</td>
                  <td>
                    {b.canCancel && <button className="secondary small" onClick={() => cancel(b)}>Cancel</button>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}
