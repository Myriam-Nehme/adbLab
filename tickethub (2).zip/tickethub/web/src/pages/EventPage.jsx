import { useCallback, useEffect, useState } from 'react';
import { api, dateTime, money } from '../api.js';
import { go } from '../router.js';

const MAX_SEATS = 6;

export default function EventPage({ eventId, user }) {
  const [event, setEvent] = useState(null);
  const [seats, setSeats] = useState([]);
  const [selected, setSelected] = useState([]);      // selected seat ids
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    const [ev, seatList] = await Promise.all([api.event(eventId), api.seats(eventId)]);
    setEvent(ev);
    setSeats(seatList);

    const free = new Set(seatList.filter((s) => !s.isTaken).map((s) => s.seatId));
    setSelected((current) => current.filter((id) => free.has(id)));
  }, [eventId]);

  useEffect(() => {
    load().catch((e) => setError(e.message));
  }, [load]);

  function toggle(seat) {
    setNotice('');
    setError('');
    if (seat.isTaken) return;
    if (selected.includes(seat.seatId)) {
      setSelected(selected.filter((id) => id !== seat.seatId));
    } else if (selected.length >= MAX_SEATS) {
      setError(`You can select at most ${MAX_SEATS} seats.`);
    } else {
      setSelected([...selected, seat.seatId]);
    }
  }

  async function book() {
    setError('');
    setNotice('');
    if (!user) {
      sessionStorage.setItem('afterLogin', `/events/${eventId}`);
      go('/login');
      return;
    }
    setBusy(true);
    try {
      const result = await api.book(eventId, selected);
      setNotice(`Booking #${result.bookingId} confirmed: ${selected.length} seat(s), ${money(total)}.`);
      setSelected([]);
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
      await load().catch(() => {});  // show the latest seat map in every case
    }
  }

  if (error && !event) return <p className="error">{error}</p>;
  if (!event) return <p className="muted">Loading…</p>;

  const priceOf = (seat) => (seat.category === 'VIP' ? event.vipPrice : event.standardPrice);
  const byId = new Map(seats.map((s) => [s.seatId, s]));
  const chosen = selected.map((id) => byId.get(id)).filter(Boolean);
  const total = chosen.reduce((sum, s) => sum + priceOf(s), 0);

  const rows = new Map();
  for (const seat of seats) {
    if (!rows.has(seat.row)) rows.set(seat.row, []);
    rows.get(seat.row).push(seat);
  }

  const bookable = event.status === 'Scheduled' && new Date(event.eventDate) > new Date();

  return (
    <>
      <a href="#/events" className="back">← All events</a>
      <h1>{event.title}</h1>
      <p className="muted">
        {dateTime(event.eventDate)} · {event.venueName}, {event.city} · {event.seatsLeft} seats left
      </p>

      {!bookable && <p className="error">This event can no longer be booked.</p>}

      <div className="legend">
        <span><i className="seat free" /> Standard {money(event.standardPrice)}</span>
        <span><i className="seat free vip" /> VIP {money(event.vipPrice)}</span>
        <span><i className="seat selected" /> Your selection</span>
        <span><i className="seat taken" /> Taken</span>
        <button className="secondary small" onClick={() => load().catch((e) => setError(e.message))}>
          Refresh seats
        </button>
      </div>

      <div className="seatmap-wrap">
        <div className="stage">STAGE</div>
        <div className="seatmap">
          {[...rows.entries()].map(([row, rowSeats]) => (
            <div className="seat-row" key={row}>
              <span className="row-label">{row}</span>
              {rowSeats.map((seat) => {
                const isSelected = selected.includes(seat.seatId);
                const cls = ['seat',
                  seat.isTaken ? 'taken' : 'free',
                  seat.category === 'VIP' ? 'vip' : '',
                  isSelected ? 'selected' : ''].join(' ');
                return (
                  <button
                    key={seat.seatId}
                    className={cls}
                    disabled={seat.isTaken || !bookable}
                    title={`Row ${seat.row}, Seat ${seat.number} · ${seat.category} · ${money(priceOf(seat))}`}
                    onClick={() => toggle(seat)}
                  />
                );
              })}
            </div>
          ))}
        </div>
      </div>

      <div className="summary">
        <div>
          {chosen.length === 0
            ? <span className="muted">Click free seats to select them (up to {MAX_SEATS}).</span>
            : chosen.map((s) => `Row ${s.row} Seat ${s.number} (${s.category})`).join(', ')}
        </div>
        <div className="summary-actions">
          <strong>{money(total)}</strong>
          <button onClick={book} disabled={busy || chosen.length === 0 || !bookable}>
            {busy ? 'Booking…' : user ? 'Book seats' : 'Log in to book'}
          </button>
        </div>
      </div>

      {notice && <p className="success">{notice} <a href="#/bookings">See my bookings</a></p>}
      {error && <p className="error">{error}</p>}
    </>
  );
}
