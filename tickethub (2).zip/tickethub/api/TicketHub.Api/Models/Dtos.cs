using System.ComponentModel.DataAnnotations;

namespace TicketHub.Api.Models;

public record LoginRequest(
    [Required, EmailAddress, StringLength(255)] string Email,
    [Required, StringLength(100)] string Password);

public record RegisterRequest(
    [Required, StringLength(100)] string FullName,
    [Required, EmailAddress, StringLength(255)] string Email,
    [Required, StringLength(100, MinimumLength = 8)] string Password);

public record BookRequest(
    [Range(1, int.MaxValue)] int EventId,
    [Required, MinLength(1), MaxLength(6)] List<int> SeatIds);

public record CreateEventRequest(
    [Range(1, int.MaxValue)] int VenueId,
    [Required, StringLength(150)] string Title,
    [Required] DateTime? EventDate,
    [Range(0.01, 100000)] decimal StandardPrice,
    [Range(0.01, 100000)] decimal VipPrice);

public record UserDto(int CustomerId, string FullName, string Email, string Role);

public record VenueDto(int VenueId, string Name, string City);

public record EventSummaryDto(
    int EventId, string Title, DateTime EventDate, decimal StandardPrice, decimal VipPrice,
    string VenueName, string City, int Capacity, int SeatsLeft);

public record EventDetailDto(
    int EventId, string Title, DateTime EventDate, string Status, decimal StandardPrice, decimal VipPrice,
    int VenueId, string VenueName, string City, int SeatsLeft);

public record SeatDto(int SeatId, byte Row, byte Number, string Category, bool IsTaken);

public record BookingDto(
    int BookingId, DateTime BookingDate, decimal TotalAmount, string Status,
    int EventId, string Title, DateTime EventDate, string VenueName,
    int SeatCount, string Seats, bool CanCancel);

public record SalesRowDto(
    int EventId, string Title, DateTime EventDate, string Status, string VenueName,
    int TicketsSold, decimal Revenue, int Capacity, decimal FillRatePct);

public record MonthlySalesDto(int Month, int TicketsSold, decimal Revenue, decimal RunningRevenue);

public record CategorySalesDto(string Category, int TicketsSold, decimal Revenue);
