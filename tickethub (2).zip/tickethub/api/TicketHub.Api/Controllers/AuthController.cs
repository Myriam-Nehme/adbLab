using System.Data;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TicketHub.Api.Data;
using TicketHub.Api.Models;

namespace TicketHub.Api.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase
{
    private readonly Db _db;

    public AuthController(Db db)
    {
        _db = db;
    }

    [HttpPost("register")]
    public async Task<ActionResult<UserDto>> Register(RegisterRequest request)
    {
        await using var connection = await _db.OpenAsync();
        await using var command = Db.Procedure(connection, "app.usp_RegisterCustomer");

        command.Parameters.Add("@FullName", SqlDbType.NVarChar, 100).Value = request.FullName;
        command.Parameters.Add("@Email", SqlDbType.NVarChar, 255).Value = request.Email;
        command.Parameters.Add("@Password", SqlDbType.NVarChar, 100).Value = request.Password;
        var newId = command.Parameters.Add("@CustomerID", SqlDbType.Int);
        newId.Direction = ParameterDirection.Output;

        await command.ExecuteNonQueryAsync();          // duplicate email -> 50003 -> 409

        var user = new UserDto((int)newId.Value, request.FullName.Trim(), request.Email.Trim(), "Customer");
        await SignInAsync(user);
        return StatusCode(StatusCodes.Status201Created, user);
    }

    [HttpPost("login")]
    public async Task<ActionResult<UserDto>> Login(LoginRequest request)
    {
        await using var connection = await _db.OpenAsync();
        await using var command = Db.Procedure(connection, "app.usp_Login");

        command.Parameters.Add("@Email", SqlDbType.NVarChar, 255).Value = request.Email;
        command.Parameters.Add("@Password", SqlDbType.NVarChar, 100).Value = request.Password;

        await using var reader = await command.ExecuteReaderAsync();
        if (!await reader.ReadAsync())
        {

            return Unauthorized(new { error = "Wrong email or password." });
        }

        var user = new UserDto(
            (int)reader["CustomerID"],
            (string)reader["FullName"],
            (string)reader["Email"],
            (string)reader["Role"]);

        await SignInAsync(user);
        return Ok(user);
    }

    [HttpPost("logout")]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return NoContent();
    }

    [Authorize]
    [HttpGet("me")]
    public ActionResult<UserDto> Me()
    {
        return new UserDto(
            User.CustomerId(),
            User.FindFirstValue(ClaimTypes.Name)!,
            User.FindFirstValue(ClaimTypes.Email)!,
            User.FindFirstValue(ClaimTypes.Role)!);
    }

    private Task SignInAsync(UserDto user)
    {
        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, user.CustomerId.ToString()),
            new(ClaimTypes.Name, user.FullName),
            new(ClaimTypes.Email, user.Email),
            new(ClaimTypes.Role, user.Role)
        };
        var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
        return HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity));
    }
}
