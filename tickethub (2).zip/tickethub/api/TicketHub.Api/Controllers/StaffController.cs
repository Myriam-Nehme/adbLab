using System.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TicketHub.Api.Data;
using TicketHub.Api.Models;

namespace TicketHub.Api.Controllers;

[ApiController]
[Route("api")]
[Authorize(Roles = "Staff")]
public class StaffController : ControllerBase
{
    private readonly Db _db;

    public StaffController(Db db)
    {
        _db = db;
    }

    [HttpGet("venues")]
    public async Task<ActionResult<List<VenueDto>>> Venues()
    {
        await using var connection = await _db.OpenAsync();
        await using var command = Db.Procedure(connection, "app.usp_GetVenues");
        await using var reader = await command.ExecuteReaderAsync();

        var venues = new List<VenueDto>();
        while (await reader.ReadAsync())
        {
            venues.Add(new VenueDto((int)reader["VenueID"], (string)reader["Name"], (string)reader["City"]));
        }
        return venues;
    }

    [HttpGet("reports/sales")]
    public async Task<ActionResult<List<SalesRowDto>>> Sales([FromQuery] DateTime from, [FromQuery] DateTime to)
    {
        await using var connection = await _db.OpenAsync();
        await using var command = Db.Procedure(connection, "app.usp_SalesReport");
        command.Parameters.Add("@FromDate", SqlDbType.Date).Value = from.Date;
        command.Parameters.Add("@ToDate", SqlDbType.Date).Value = to.Date;

        await using var reader = await command.ExecuteReaderAsync();
        var rows = new List<SalesRowDto>();
        while (await reader.ReadAsync())
        {
            rows.Add(new SalesRowDto(
                (int)reader["EventID"],
                (string)reader["Title"],
                (DateTime)reader["EventDate"],
                (string)reader["Status"],
                (string)reader["VenueName"],
                (int)reader["TicketsSold"],
                (decimal)reader["Revenue"],
                (int)reader["Capacity"],
                (decimal)reader["FillRatePct"]));
        }
        return rows;
    }

    [HttpGet("reports/monthly")]
    public async Task<ActionResult<List<MonthlySalesDto>>> Monthly([FromQuery] int year)
    {
        await using var connection = await _db.OpenAsync();
        await using var command = Db.Procedure(connection, "app.usp_MonthlySales");
        command.Parameters.Add("@Year", SqlDbType.Int).Value = year;

        await using var reader = await command.ExecuteReaderAsync();
        var rows = new List<MonthlySalesDto>();
        while (await reader.ReadAsync())
        {
            rows.Add(new MonthlySalesDto(
                (int)reader["Month"],
                (int)reader["TicketsSold"],
                (decimal)reader["Revenue"],
                (decimal)reader["RunningRevenue"]));
        }
        return rows;
    }
}
