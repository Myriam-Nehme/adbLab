using System.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TicketHub.Api.Data;
using TicketHub.Api.Models;

namespace TicketHub.Api.Controllers;

[ApiController]
[Route("api/bookings")]
[Authorize]
public class BookingsController : ControllerBase
{
    private readonly Db _db;

    public BookingsController(Db db)
    {
        _db = db;
    }

    [HttpPost]
    public async Task<IActionResult> Book(BookRequest request)
    {

        var seats = new DataTable();
        seats.Columns.Add("SeatID", typeof(int));
        foreach (int seatId in request.SeatIds.Distinct())
        {
            seats.Rows.Add(seatId);
        }

        await using var connection = await _db.OpenAsync();
        await using var command = Db.Procedure(connection, "app.usp_BookSeats");

        command.Parameters.Add("@CustomerID", SqlDbType.Int).Value = User.CustomerId();   // from the cookie
        command.Parameters.Add("@EventID", SqlDbType.Int).Value = request.EventId;

        var seatList = command.Parameters.Add("@SeatIds", SqlDbType.Structured);
        seatList.TypeName = "app.SeatIdList";
        seatList.Value = seats;

        var bookingId = command.Parameters.Add("@BookingID", SqlDbType.Int);
        bookingId.Direction = ParameterDirection.Output;

        await command.ExecuteNonQueryAsync();

        return StatusCode(StatusCodes.Status201Created, new { bookingId = (int)bookingId.Value });
    }

    [HttpGet("mine")]
    public async Task<ActionResult<List<BookingDto>>> Mine()
    {
        await using var connection = await _db.OpenAsync();
        await using var command = Db.Procedure(connection, "app.usp_GetCustomerBookings");
        command.Parameters.Add("@CustomerID", SqlDbType.Int).Value = User.CustomerId();

        await using var reader = await command.ExecuteReaderAsync();
        var bookings = new List<BookingDto>();
        while (await reader.ReadAsync())
        {
            bookings.Add(new BookingDto(
                (int)reader["BookingID"],
                (DateTime)reader["BookingDate"],
                (decimal)reader["TotalAmount"],
                (string)reader["Status"],
                (int)reader["EventID"],
                (string)reader["Title"],
                (DateTime)reader["EventDate"],
                (string)reader["VenueName"],
                (int)reader["SeatCount"],
                (string)reader["Seats"],
                (bool)reader["CanCancel"]));
        }
        return bookings;
    }

    [HttpPost("{id:int}/cancel")]
    public async Task<IActionResult> Cancel(int id)
    {
        await using var connection = await _db.OpenAsync();
        await using var command = Db.Procedure(connection, "app.usp_CancelBooking");
        command.Parameters.Add("@BookingID", SqlDbType.Int).Value = id;
        command.Parameters.Add("@CustomerID", SqlDbType.Int).Value = User.CustomerId();

        await command.ExecuteNonQueryAsync();      // someone else's booking -> 50002 -> 404
        return NoContent();
    }
}
