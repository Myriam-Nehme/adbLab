using System.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TicketHub.Api.Data;
using TicketHub.Api.Models;

namespace TicketHub.Api.Controllers;

[ApiController]
[Route("api/events")]
public class EventsController : ControllerBase
{
    private readonly Db _db;

    public EventsController(Db db)
    {
        _db = db;
    }

    [HttpGet]
    public async Task<ActionResult<List<EventSummaryDto>>> GetUpcoming()
    {
        await using var connection = await _db.OpenAsync();
        await using var command = Db.Procedure(connection, "app.usp_GetUpcomingEvents");
        await using var reader = await command.ExecuteReaderAsync();

        var events = new List<EventSummaryDto>();
        while (await reader.ReadAsync())
        {
            events.Add(new EventSummaryDto(
                (int)reader["EventID"],
                (string)reader["Title"],
                (DateTime)reader["EventDate"],
                (decimal)reader["StandardPrice"],
                (decimal)reader["VipPrice"],
                (string)reader["VenueName"],
                (string)reader["City"],
                (int)reader["Capacity"],
                (int)reader["SeatsLeft"]));
        }
        return events;
    }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<EventDetailDto>> GetById(int id)
    {
        await using var connection = await _db.OpenAsync();
        await using var command = Db.Procedure(connection, "app.usp_GetEvent");
        command.Parameters.Add("@EventID", SqlDbType.Int).Value = id;

        await using var reader = await command.ExecuteReaderAsync();   // unknown id -> 50002 -> 404
        await reader.ReadAsync();

        return new EventDetailDto(
            (int)reader["EventID"],
            (string)reader["Title"],
            (DateTime)reader["EventDate"],
            (string)reader["Status"],
            (decimal)reader["StandardPrice"],
            (decimal)reader["VipPrice"],
            (int)reader["VenueID"],
            (string)reader["VenueName"],
            (string)reader["City"],
            (int)reader["SeatsLeft"]);
    }

    [HttpGet("{id:int}/seats")]
    public async Task<ActionResult<List<SeatDto>>> GetSeats(int id)
    {
        await using var connection = await _db.OpenAsync();
        await using var command = Db.Procedure(connection, "app.usp_GetEventSeats");
        command.Parameters.Add("@EventID", SqlDbType.Int).Value = id;

        await using var reader = await command.ExecuteReaderAsync();
        var seats = new List<SeatDto>();
        while (await reader.ReadAsync())
        {
            seats.Add(new SeatDto(
                (int)reader["SeatID"],
                (byte)reader["SeatRow"],
                (byte)reader["SeatNumber"],
                (string)reader["Category"],
                (bool)reader["IsTaken"]));
        }
        return seats;
    }

    [Authorize(Roles = "Staff")]
    [HttpPost]
    public async Task<IActionResult> Create(CreateEventRequest request)
    {
        await using var connection = await _db.OpenAsync();
        await using var command = Db.Procedure(connection, "app.usp_CreateEvent");

        command.Parameters.Add("@VenueID", SqlDbType.Int).Value = request.VenueId;
        command.Parameters.Add("@Title", SqlDbType.NVarChar, 150).Value = request.Title;
        command.Parameters.Add("@EventDate", SqlDbType.DateTime2).Value = request.EventDate!.Value;
        AddMoney(command, "@StandardPrice", request.StandardPrice);
        AddMoney(command, "@VipPrice", request.VipPrice);
        var newId = command.Parameters.Add("@EventID", SqlDbType.Int);
        newId.Direction = ParameterDirection.Output;

        await command.ExecuteNonQueryAsync();
        return StatusCode(StatusCodes.Status201Created, new { eventId = (int)newId.Value });
    }

    [Authorize(Roles = "Staff")]
    [HttpGet("{id:int}/sales")]
    public async Task<ActionResult<List<CategorySalesDto>>> GetSales(int id)
    {
        await using var connection = await _db.OpenAsync();
        await using var command = Db.Procedure(connection, "app.usp_GetEventSales");
        command.Parameters.Add("@EventID", SqlDbType.Int).Value = id;

        await using var reader = await command.ExecuteReaderAsync();
        var rows = new List<CategorySalesDto>();
        while (await reader.ReadAsync())
        {
            rows.Add(new CategorySalesDto(
                (string)reader["Category"],
                (int)reader["TicketsSold"],
                (decimal)reader["Revenue"]));
        }
        return rows;
    }

    private static void AddMoney(Microsoft.Data.SqlClient.SqlCommand command, string name, decimal value)
    {
        var parameter = command.Parameters.Add(name, SqlDbType.Decimal);
        parameter.Precision = 10;
        parameter.Scale = 2;
        parameter.Value = value;
    }
}
