using System.Security.Claims;

namespace TicketHub.Api.Data;

public static class ClaimsExtensions
{

    public static int CustomerId(this ClaimsPrincipal user)
    {
        return int.Parse(user.FindFirstValue(ClaimTypes.NameIdentifier)!);
    }
}
