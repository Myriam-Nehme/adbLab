using System.Data;
using Microsoft.Data.SqlClient;

namespace TicketHub.Api.Data;

public sealed class Db
{
    private readonly string _connectionString;

    public Db(string connectionString)
    {
        _connectionString = connectionString;
    }

    public async Task<SqlConnection> OpenAsync()
    {
        var connection = new SqlConnection(_connectionString);
        await connection.OpenAsync();
        return connection;
    }

    public static SqlCommand Procedure(SqlConnection connection, string name)
    {
        return new SqlCommand(name, connection)
        {
            CommandType = CommandType.StoredProcedure,
            CommandTimeout = 30
        };
    }
}
