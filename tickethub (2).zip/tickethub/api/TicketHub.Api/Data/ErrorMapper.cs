using Microsoft.Data.SqlClient;

namespace TicketHub.Api.Data;

public static class ErrorMapper
{
    public static (int Status, string Message) Map(Exception? error)
    {
        if (error is SqlException sql)
        {
            return sql.Number switch
            {
                50001 => (StatusCodes.Status400BadRequest, sql.Message),          // invalid input
                50002 => (StatusCodes.Status404NotFound, sql.Message),            // not found
                50003 => (StatusCodes.Status409Conflict, sql.Message),            // seat taken, email used
                50004 => (StatusCodes.Status422UnprocessableEntity, sql.Message), // business rule
                1205  => (StatusCodes.Status409Conflict,
                          "Someone else is booking these seats right now. Please try again."), // deadlock victim
                _     => (StatusCodes.Status500InternalServerError, "A database error occurred.")
            };
        }

        return (StatusCodes.Status500InternalServerError, "An unexpected error occurred.");
    }
}
